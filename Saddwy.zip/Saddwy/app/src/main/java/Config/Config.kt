package Config

import android.content.SharedPreferences
import android.media.session.MediaSession.Token

class Config {
    var urlBase = "http://192.168.146.144:8000/api/v01/"



    companion object {
        var Token = ""
    }


}